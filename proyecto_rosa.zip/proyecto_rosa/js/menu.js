$(document).ready(main);

var contador = 1 ; 

function main() {
   $('.bt-menu').click(function(){

    if (contador == 1) {
        $('nav').animate({
            left: '0'
        });
        contador = 0;
    }
    else{
        contador = 1;
        $('nav').animate({
            left: '-100%'
        });
     }


   });
   
   document.getElementById("closePopup").addEventListener("click", function() {
    document.getElementById("subscribePopup").style.display = "none";
});


}




const form = document.getElementById('contactForm');

        form.addEventListener('submit', function (event) {
            event.preventDefault();
            alert('¡Gracias por contactarnos! Hemos recibido tu mensaje.');
        });

      
       